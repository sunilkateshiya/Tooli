//
//  Addcell.swift
//  Tooli
//
//  Created by Impero-Moin on 21/01/17.
//  Copyright © 2017 Moin Shirazi. All rights reserved.
//

import UIKit

class Addcell: UICollectionViewCell {
    
}
