     //
//  PortfolioCell.swift
//  Tooli
//
//  Created by Impero-Moin on 20/01/17.
//  Copyright © 2017 Moin Shirazi. All rights reserved.
//

import UIKit

class PortfolioCell: UICollectionViewCell {
    
     @IBOutlet weak var PortfolioImage: UIImageView!
}
